import {router} from 'expo-router';
// Every button links through here. Change the strings to your real routes; nothing else needs touching.
export const R={
  job:(id:string)=>`/job/${id}`, editJob:(id:string)=>`/job/${id}/edit`,
  boost:(id:string,step=1,v?:number)=>`/job/${id}/boost?step=${step}${v?`&v=${v}`:''}`,
  employer:(id:string)=>`/employer/${id}`, employerJobs:(id:string)=>`/employer/${id}/jobs`,
  chat:(id:string)=>`/messages/${id}`, pickLocation:'/pick-location',
};
export const go=(p:string)=>router.push(p as never);
