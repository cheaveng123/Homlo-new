// Lagoon & Sunrise tokens. If you already have a tokens file, delete this and re-point the imports.
export const c={teal:'#0E7C86',deep:'#073B42',hdr:'#052E34',tint:'#D8F0EE',tint2:'#B5E2DF',bg:'#F4F8F8',line:'#E4ECEC',track:'#D9EAEA',tx:'#14272B',mu:'#58696B',sun:'#F5B52B',clay:'#C4531F',clayT:'#FDE6DA',clayI:'#8A3A12',cream:'#FFF1D2',cream2:'#FFE0A0',ink:'#7A4300',dusk:'#6B4FA0'};
// Fonts: @expo-google-fonts/plus-jakarta-sans, @expo-google-fonts/inter. For Khmer map these keys to Noto Sans Khmer at the same weights.
export const f={h:'PlusJakartaSans_800ExtraBold',hb:'PlusJakartaSans_700Bold',b:'Inter_400Regular',m:'Inter_500Medium',s:'Inter_600SemiBold'};
export const sh={shadowColor:'#0E7C86',shadowOpacity:0.18,shadowRadius:16,shadowOffset:{width:0,height:8},elevation:4};
