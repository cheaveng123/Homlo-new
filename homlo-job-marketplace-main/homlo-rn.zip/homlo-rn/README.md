# Homlo Jobs redesign (Expo, expo-router, Reanimated)
Install: npx expo install react-native-reanimated react-native-svg expo-linear-gradient react-native-safe-area-context @expo-google-fonts/inter @expo-google-fonts/plus-jakarta-sans
Copy `src/` and `app/` into your project (merge routes). Edit `src/routes.ts` so every link points at your real routes.
Each screen has `TODO` comments where your existing hooks replace the sample data. Logic, API calls and translations are untouched.
Reduce Motion: Reanimated layout/entering animations follow the system setting; looping effects check useReducedMotion().
